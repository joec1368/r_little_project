library(readr)
cpi <- read_csv("cpi.csv")
View(cpi)

library(readr)
Data_表格_1 <- read_csv("Data-表格 1.csv")
View(Data_表格_1)

library(readr)
gross_domestic_product <- read_csv("gross-domestic-product.csv")
View(gross_domestic_product)

library(readr)
inflation <- read_csv("inflation.csv")
View(inflation)

library(readr)
sugar_prices_historical_chart_data_nwq <- read_csv("sugar-prices-historical-chart-data nwq.csv")
View(sugar_prices_historical_chart_data_nwq)

library(readr)
wheat_prices_historical_chart_datanew <- read_csv("wheat-prices-historical-chart-datanew.csv")
View(wheat_prices_historical_chart_datanew)

AUSgdp=as.numeric(unlist(gross_domestic_product[1:6,4]))
CHIgdp=as.numeric(unlist(gross_domestic_product[7:13,4]))
KORgdp=as.numeric(unlist(gross_domestic_product[14:20,4]))
UKgdp=as.numeric(unlist(gross_domestic_product[21:27,4]))
usagdp=as.numeric(unlist(gross_domestic_product[28:34,4]))
AUSgdp=c(1.02,1.06,1.10,1.12,1.14,1.17,1.21)
AUSgdp=AUSgdp*1000000000000


WORgdptemp=matrix(c(AUSgdp,CHIgdp,KORgdp,UKgdp,usagdp),5,7,byrow=T)

WORgdpmean=apply(WORgdptemp,2,mean)

mt=c(2006:2012)

layout(matrix(c(1,2,3,4,5,6),3,2))


plot(mt,CHIgdp,main="the GDP of China",ylab="gdp",xlab="year")
legend("topright",pch=1,col="red",legend="gdp")
plot(mt,KORgdp,main="the GDP of Korea",ylab="gdp",xlab="year")
legend("topright",pch=1,col="red",legend="gdp")
plot(mt,UKgdp,main="the GDP of UK",ylab="gdp",xlab="year")
legend("topright",pch=1,col="red",legend="gdp")
plot(mt,usagdp,main="the GDP of the USA",ylab="gdp",xlab="year")
legend("topright",pch=1,col="red",legend="gdp")
plot(mt,AUSgdp,main="the GDP of Australia",ylab="gdp",xlab="year")
legend("topright",pch=1,col="red",legend="gdp")
plot(mt,WORgdpmean,main="the GDP around the world",ylab="gdp",xlab="year")
legend("topright",pch=1,col="red",legend="gdp")

dev.off()

layout(matrix(1,1,1))

plot(mt,WORgdpmean,pch=1,col=2,ylim=c(1000000000000,20000000000000),xlab="year",ylab="gdp",main="GDP")
points(x=mt,y=CHIgdp,pch=2,col=3)
points(x=mt,y=KORgdp,pch=3,col=4)
points(x=mt,y=UKgdp,pch=4,col=5)
points(x=mt,y=usagdp,pch=5,col=6)
points(x=mt,y=AUSgdp,pch=6,col=7)
legend("top", pch=c(1:6),col=c(2:7),legend=c("WOR","CHI","KOR","UK","USA","AUS"),horiz=T)

dev.off()

JAPun=unlist(as.numeric(Data_表格_1[3,5:11]))
UKun=unlist(as.numeric(Data_表格_1[10,5:11]))
USAun=unlist(as.numeric(Data_表格_1[17,5:11]))
FRAun=unlist(as.numeric(Data_表格_1[24,5:11]))
GERun=unlist(as.numeric(Data_表格_1[31,5:11]))
HKun=unlist(as.numeric(Data_表格_1[38,5:11]))
KORun=unlist(as.numeric(Data_表格_1[45,5:11]))

layout(matrix(c(1,2,3,4),2,2))

WORuntemp=matrix(c(JAPun,UKun,USAun,FRAun,GERun,HKun,KORun),7,7,byrow=T)

WORunmean=apply(WORuntemp,2,mean)

plot(mt,JAPun,main="Unemployment Rate in Japan",ylab="the rate of unenployment(%)",xlab="year")
legend("topright",pch=1,col="red",legend="rate")
plot(mt,UKun,main="Unemployment Rate in UK",ylab="the rate of unenployment(%)",xlab="year")
legend("topright",pch=1,col="red",legend="rate")
plot(mt,USAun,main="Unemployment Rate in the USA",ylab="the rate of unenployment(%)",xlab="year")
legend("topright",pch=1,col="red",legend="rate")
plot(mt,FRAun,main="Unemployment Rate in France",ylab="the rate of unenployment(%)",xlab="year")
legend("topright",pch=1,col="red",legend="rate")
plot(mt,GERun,main="Unemployment Rate in German",ylab="the rate of unenployment(%)",xlab="year")
legend("topright",pch=1,col="red",legend="rate")
plot(mt,HKun,main="Unemployment Rate in HK",ylab="the rate of unenployment(%)",xlab="year")
legend("topright",pch=1,col="red",legend="rate")
plot(mt,KORun,main="Unemployment Rate in Korea",ylab="the rate of unenployment(%)",xlab="year")
legend("topright",pch=1,col="red",legend="rate")
plot(mt,WORunmean,main="Unemployment Rate around the world",ylab="the rate of unenployment(%)",xlab="year")
legend("topright",pch=1,col="red",legend="rate")

dev.off()

layout(matrix(1,1,1))

plot(mt,WORunmean,pch=1,col=2,ylim=c(1,10),xlab="year",ylab="the rate of unenployment(%)",main="Unemployment Rate")
points(x=mt,y=JAPun,pch=2,col=3)
points(x=mt,y=UKun,pch=3,col=4)
points(x=mt,y=USAun,pch=4,col=5)
points(x=mt,y=FRAun,pch=5,col=6)
points(x=mt,y=GERun,pch=6,col=7)
points(x=mt,y=HKun,pch=7,col=8)
points(x=mt,y=KORun,pch=8,col=9)

legend("bottom", pch=c(1:8),col=c(2:9),legend=c("WOR","JAP","UK","USA","FRA","GER","HK","KOR"),horiz=T,text.width=0.5,cex=0.5)

dev.off()

CHIcpi=unlist(as.numeric(cpi[5,5:11]))
FRAcpi=unlist(as.numeric(cpi[6,5:11]))
UKcpi=unlist(as.numeric(cpi[7,5:11]))
HKcpi=unlist(as.numeric(cpi[8,5:11]))
JAPcpi=unlist(as.numeric(cpi[9,5:11]))
SINcpi=unlist(as.numeric(cpi[10,5:11]))
USAcpi=unlist(as.numeric(cpi[11,5:11]))

WORcpitemp=matrix(c(CHIcpi,UKcpi,USAcpi,FRAcpi,JAPcpi,HKcpi,SINcpi),7,7,byrow=T)

WORcpimean=apply(WORcpitemp,2,mean)

layout(matrix(c(1,2,3,4),2,2))

plot(mt,JAPcpi,main="Consumer Price Index in Japan",ylab="cpi",xlab="year")
legend("topleft",pch=1,col="red",legend="cpi")
plot(mt,UKcpi,main="Consumer Price Index in UK",ylab="cpi",xlab="year")
legend("topleft",pch=1,col="red",legend="cpi")
plot(mt,USAcpi,main="Consumer Price Index in the USA",ylab="cpi",xlab="year")
legend("topleft",pch=1,col="red",legend="cpi")
plot(mt,FRAcpi,main="Consumer Price Index in France",ylab="cpi",xlab="year")
legend("topleft",pch=1,col="red",legend="cpi")
plot(mt,SINcpi,main="Consumer Price Index in German",ylab="cpi",xlab="year")
legend("topleft",pch=1,col="red",legend="cpi")
plot(mt,HKcpi,main="Consumer Price Index in HK",ylab="cpi",xlab="year")
legend("topleft",pch=1,col="red",legend="cpi")
plot(mt,CHIcpi,main="Consumer Price Index in China",ylab="cpi",xlab="year")
legend("topleft",pch=1,col="red",legend="cpi")
plot(mt,WORcpimean,main="Consumer Price Index around the world",ylab="cpi",xlab="year")
legend("topleft",pch=1,col="red",legend="cpi")

layout(matrix(1,1,1))

plot(mt,WORcpimean,pch=1,col=2,ylim=c(90,110),xlab="year",ylab="cpi",main="Consumer Price index")
points(x=mt,y=JAPcpi,pch=2,col=3)
points(x=mt,y=UKcpi,pch=3,col=4)
points(x=mt,y=USAcpi,pch=4,col=5)
points(x=mt,y=FRAcpi,pch=5,col=6)
points(x=mt,y=SINcpi,pch=6,col=7)
points(x=mt,y=HKcpi,pch=7,col=8)
points(x=mt,y=CHIcpi,pch=8,col=9)

legend("topleft", pch=c(1:8),col=c(2:9),legend=c("WOR","JAP","UK","USA","FRA","SIN","HK","CHI"),horiz=F,text.width=0.5,cex=0.8)

dev.off()

GERinf=unlist(as.numeric(inflation[6,5:11]))
FRAinf=unlist(as.numeric(inflation[8,5:11]))
UKinf=unlist(as.numeric(inflation[9,5:11]))
JAPinf=unlist(as.numeric(inflation[11,5:11]))
USAinf=unlist(as.numeric(inflation[12,5:11]))

WORinftemp=matrix(c(UKinf,USAinf,FRAinf,JAPinf,GERinf),5,7,byrow=T)

WORinfmean=apply(WORinftemp,2,mean)

layout(matrix(c(1,2,3,4),2,2))

plot(mt,JAPinf,main="Inflation in Japan",ylab="inf",xlab="year")
legend("topleft",pch=1,col="red",legend="inflation",cex=0.5)
plot(mt,UKinf,main="Inflation in UK",ylab="inf",xlab="year")
legend("topleft",pch=1,col="red",legend="inflation",cex=0.5)
plot(mt,USAinf,main="Inflation in the USA",ylab="inf",xlab="year")
legend("topleft",pch=1,col="red",legend="inflation",cex=0.5)
plot(mt,FRAinf,main="Inflation in France",ylab="inf",xlab="year")
legend("topleft",pch=1,col="red",legend="inflation",cex=0.5)
dev.off()
layout(matrix(c(1,2),1,2))
plot(mt,GERinf,main="Inflation in German",ylab="inf",xlab="year")
legend("topleft",pch=1,col="red",legend="inflation",cex=0.5)
plot(mt,WORinfmean,main="Inflation around the world",ylab="inf",xlab="year")
legend("topleft",pch=1,col="red",legend="inflation",cex=0.5)

dev.off()

layout(1,1,1)

plot(mt,WORinfmean,pch=1,col=2,ylim=c(1,7),xlab="year",ylab="inf",main="Inflation")
points(x=mt,y=JAPinf,pch=2,col=3)
points(x=mt,y=UKinf,pch=3,col=4)
points(x=mt,y=USAinf,pch=4,col=5)
points(x=mt,y=FRAinf,pch=5,col=6)
points(x=mt,y=GERinf,pch=6,col=7)

legend("topleft", pch=c(1:6),col=c(2:7),legend=c("WOR","JAP","UK","USA","FRA","GER"),horiz=F,text.width=0.5,cex=0.8)

dev.off()

sugarprice=sugar_prices_historical_chart_data_nwq[,2]
sugar2006=apply(sugarprice[1:249,1],2,mean)
sugar2007=apply(sugarprice[250:498,1],2,mean)
sugar2008=apply(sugarprice[499:751,1],2,mean)
sugar2009=apply(sugarprice[752:1003,1],2,mean)
sugar2010=apply(sugarprice[1004:1255,1],2,mean)
sugar2011=apply(sugarprice[1256:1506,1],2,mean)
sugar2012=apply(sugarprice[1507:1758,1],2,mean)
sugar=matrix(c(sugar2006,sugar2007,sugar2008,sugar2009,sugar2010,sugar2011,sugar2012))


wheatprice=wheat_prices_historical_chart_datanew[,2]
wheat2006=apply(wheatprice[1:251,1],2,mean)
wheat2007=apply(wheatprice[252:503,1],2,mean)
wheat2008=apply(wheatprice[504:756,1],2,mean)
wheat2009=apply(wheatprice[757:1008,1],2,mean)
wheat2010=apply(wheatprice[1009:1260,1],2,mean)
wheat2011=apply(wheatprice[1261:1512,1],2,mean)
wheat2012=apply(wheatprice[1513:1764,1],2,mean)
wheat=matrix(c(wheat2006,wheat2007,wheat2008,wheat2009,wheat2010,wheat2011,wheat2012))

layout(matrix(c(1,2),2,2))
plot(mt,sugar,main="Sugar Price",ylab="money (US dollar)",xlab="year",)
legend("topleft",pch=1,col="red",legend="price",cex=1)
plot(mt,wheat,main="Wheat Price",ylab="money (US dollar)",xlab="year",)
legend("topleft",pch=1,col="red",legend="price",cex=1)

dev.off()

layout(1,1,1)

plot(mt,sugar,main="Price",ylab="money (US dollar)",xlab="year",ylim=c(0.1,8),pch=1,col=2)
points(x=mt,y=wheat,pch=2,col=3)
legend("center",pch=c(1:2),col=c(2:3),legend=c("sugar","wheat"))

dev.off()

layout(matrix(c(1,2,3,4,5,6),3,2))
plot(mt,WORgdpmean,main="the GDP around the world",ylab="gdp",xlab="year")
plot(mt,WORunmean,main="Unemployment Rate around the world",ylab="the rate of unenployment(%)",xlab="year")
plot(mt,WORcpimean,main="Consumer Price Index around the world",ylab="cpi",xlab="year")
plot(mt,WORinfmean,main="Inflation around the world",ylab="inf",xlab="year")
plot(mt,sugar,main="Sugar Price",ylab="money (US dollar)",xlab="year",)
plot(mt,wheat,main="Wheat Price",ylab="money (US dollar)",xlab="year",)

